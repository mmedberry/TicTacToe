There are 2 options to run the application:
	Option 1: Download TicTacToe.jar and run.

	Option 2: Create a new Git project in Eclipse or your Java IDE of choice. 
	Make sure you have JavaFX libraries installed.
	Once the new project has been built run Main.java found within the project.

Gameplay:
	The game will start instantly when the Main class is ran. The player for X will go first and will
	select the first grid space to choose. The players will alternate choosing spaces until one wins
	or all the spaces have been chosen and a draw is reached. After the game, a button asking
	to play again will appear. Clicking the button will clear the gameboard and start over.